// Country entity
public class Country {}