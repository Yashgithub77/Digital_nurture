import React,{Component} from 'react';
export default class Posts extends Component{
constructor(){super();this.state={posts:[]}}
loadPosts(){fetch('https://jsonplaceholder.typicode.com/posts').then(r=>r.json()).then(d=>this.setState({posts:d.slice(0,10)}));}
componentDidMount(){this.loadPosts();}
componentDidCatch(e){alert(e);}
render(){return <div>{this.state.posts.map(p=><div key={p.id}><h3>{p.title}</h3><p>{p.body}</p></div>)}</div>}
}