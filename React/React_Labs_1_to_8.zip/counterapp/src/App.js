import React,{Component} from 'react';
export default class CountPeople extends Component{
constructor(){super();this.state={entry:0,exit:0}}
UpdateEntry=()=>this.setState({entry:this.state.entry+1});
UpdateExit=()=>this.setState({exit:this.state.exit+1});
render(){return <div><h2>Entry:{this.state.entry}</h2><h2>Exit:{this.state.exit}</h2><button onClick={this.UpdateEntry}>Login</button><button onClick={this.UpdateExit}>Exit</button></div>}
}