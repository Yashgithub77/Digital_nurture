import CalculateScore from './Components/CalculateScore';
export default function App(){return <CalculateScore name="Sowmya" school="IARE" total={450} goal={5}/>;}