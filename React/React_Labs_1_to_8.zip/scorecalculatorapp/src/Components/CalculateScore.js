import './mystyle.css';
export default function CalculateScore({name,school,total,goal}){
 const avg=total/goal;
 return <div className="box">
 <h2>Student Score</h2>
 <p>Name: {name}</p><p>School: {school}</p>
 <p>Total: {total}</p><p>Subjects: {goal}</p>
 <h3>Average: {avg.toFixed(2)}</h3></div>;
}