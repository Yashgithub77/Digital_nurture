import React,{Component} from 'react';
class Cart{constructor(item,price){this.item=item;this.price=price;}}
export default class OnlineShopping extends Component{
items=[new Cart('Laptop',50000),new Cart('Mouse',500),new Cart('Keyboard',1000),new Cart('Headset',1500),new Cart('PenDrive',700)];
render(){return <table border='1'><tbody>{this.items.map((i,n)=><tr key={n}><td>{i.item}</td><td>{i.price}</td></tr>)}</tbody></table>}
}